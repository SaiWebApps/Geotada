# Spec PM — Spec-Driven Development Skill for Claude Code

A product management co-pilot that enforces a strict **scope > spec > red-team > plan > implement** workflow for AI-assisted development with human-in-the-loop quality gates.

## Installation

1. Copy the `commands/` folder contents into your project's `.claude/commands/` directory
2. Copy the `templates/` folder to your project root as a reference
3. Create a `specs/NORTHSTAR.md` file in your project root (use `templates/NORTHSTAR.md` as a starting point)
4. Customize `.claude/commands/product-context.md` with your project's stable product knowledge

## Directory Structure

```
your-project/
├── .claude/
│   └── commands/
│       ├── product-context.md    # Your project's stable context (customize this)
│       ├── pm-scope.md           # Stage 1: Scoping
│       ├── pm-spec.md            # Stage 2: Behavior Spec
│       ├── pm-red-team.md        # Stage 3: Red Team Review
│       ├── pm-plan.md            # Stage 4: Implementation Plan
│       └── pm-verify.md          # Stage 5: Verification
└── specs/
    ├── NORTHSTAR.md              # Project north star (create this)
    └── YYYY-MM-DD-feature-name/  # Spec folders created by the workflow
        ├── 01-scope.md
        ├── 02-spec.md
        ├── 03-red-team.md
        ├── 04-plan.md
        └── 05-verify.md
```

## The 5 Stages

### Stage 1: Scope (`/pm-scope`)
Define what you're building, why, what you're NOT building, what already exists, and dependencies/risks. This is the "measure twice" step that prevents scope creep before any code is written.

### Stage 2: Spec (`/pm-spec`)
Write a behavior spec or contract spec with a walkthrough, acceptance criteria, and edge cases. The spec is the single source of truth for what "done" looks like.

### Stage 3: Red Team (`/pm-red-team`)
Adversarial review of the spec. Find blockers, risks, open questions, codebase conflicts, north star alignment issues, and security/privacy gaps. Every finding must have a resolution before proceeding.

### Stage 4: Plan (`/pm-plan`)
Break the spec into ordered implementation tasks with file-level detail, test definitions, a Claude Code prompt, and a best practices checklist. This is the blueprint the developer (or AI) follows.

### Stage 5: Verify (`/pm-verify`)
After implementation, verify every acceptance criterion, check best practices compliance, document autonomous decisions, and confirm no scope creep occurred.

## How It Works

Each command:
1. Reads your `specs/NORTHSTAR.md` and `.claude/commands/product-context.md` for project context
2. Reads any existing spec artifacts for the current feature
3. Executes its stage with strict quality gates
4. Outputs a markdown file in the spec folder

## Customization

### product-context.md
This is the only file you MUST customize. It holds your project's stable product knowledge:
- Vision and goals
- Technical decisions
- Current stack
- Architecture
- MVP scope and boundaries
- Team info

### NORTHSTAR.md
Your project's north star document. Contains:
- Vision
- Milestone plan with phase gates
- Architectural commitments (locked decisions)
- Explicit boundaries (what you will NOT build)
- Active build target
- Open strategic conflicts

### Best Practices Library
The red team stage audits against a best practices library. You can customize the categories in `pm-red-team.md` to match your project's needs. Default categories:
- Security and privacy
- Performance
- UX
- Accessibility

## Tips

- Run stages in order. Each stage builds on the previous one.
- The human approves each stage before moving to the next — this is the quality gate.
- Spec folders use the naming convention `specs/YYYY-MM-DD-feature-name/`.
- Keep your NORTHSTAR.md and product-context.md up to date — every command reads them.
- The red team stage is where most bugs and design issues are caught. Don't skip it.
