# Scope: [Feature Name]

**Date:** YYYY-MM-DD
**Status:** Draft

---

## What we're building

- **Deliverable 1:** Concrete description of what will be built. Specific enough to verify.
- **Deliverable 2:** Another concrete deliverable.
- **Deliverable 3:** And so on.

## Why

Connect this work to the north star and current phase gate. Why is this the right thing to build right now? What phase gate does it advance?

## What we're NOT building

- Not building X (will be a follow-up slice)
- Not changing Y (out of scope for this work)
- Not adding Z (explicitly deferred)

## What already exists

- **File/component A** (`path/to/file.ext`) — Description of current state, relevant functions, line numbers
- **API endpoint B** (`POST /api/v1/things`) — What it does, constraints, known limitations
- **Module C** (`path/to/module/`) — What it provides that this feature builds on

## Dependencies or risks

- **Risk 1:** Description of what could go wrong and why
- **Dependency 1:** External system or unfinished work this depends on

## Best practices flagged

- **Security:** Any input validation, auth, or injection concerns
- **Performance:** Any potential bottlenecks or scaling concerns
- **UX:** Any usability concerns or mental model changes
