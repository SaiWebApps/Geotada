# Project North Star

> **Last updated:** YYYY-MM · **Status:** Pre-launch

---

## Vision

<!-- One sentence: what does your product do and why does it matter? -->

---

## Milestone Plan

| Phase | Window | Gate (must pass to advance) |
|-------|--------|-----------------------------|
| **1 — Foundation** | Months 1-3 | Core pipeline working, minimum viable content live, internal quality bar passing |
| **2 — First Real Users** | Months 3-4 | Small tester cohort completes core flow, reliability targets met, organic positive signal |
| **3 — Public Launch** | Months 4-7 | Store/marketplace live, monetization active, usage targets met, organic growth signal |
| **4 — Prove It Scales** | Months 7-12 | Second market/segment live with minimal pipeline work, first enterprise/partnership conversation |

**Current phase:** Phase 1

**The MVP thesis (everything else is conditional on this):**
<!-- What is the one thing you must prove before anything else matters? -->

---

## Architectural Commitments

These are locked. Do not re-open without a documented decision entry.

<!--
List your locked technical decisions. Examples:
- **Database:** PostgreSQL with PostGIS extension
- **API style:** REST with versioned endpoints
- **Auth:** JWT-based, Supabase Auth
- **Content model:** Versioned documents with approval workflow
- **Development workflow:** Spec-to-prompt — behavior spec with acceptance criteria, then build
-->

---

## Explicit Boundaries

**Will NOT build for MVP:**
<!--
- Feature X (reason)
- Feature Y (reason)
-->

**Will NOT do (process):**
<!--
- Re-open locked decisions without a documented entry
- Build retention/monetization features before MVP thesis is validated
-->

---

## Pointers

| Document | Location | What it contains |
|----------|----------|------------------|
<!-- Link to your key project documents -->

---

## Active Build Target

<!--
What is the team building RIGHT NOW? Be specific:
- Feature name and slice
- Key technical details
- Status of spec/plan
-->

---

## Open Strategic Conflicts

<!--
Numbered list of unresolved tensions between product strategy, technical architecture, and timeline.
-->
