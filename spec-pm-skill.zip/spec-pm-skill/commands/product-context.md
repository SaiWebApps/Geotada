# Product Context Reference

This file captures the stable product knowledge that informs all 5 PM stages. Customize this file for your project. Load this alongside `specs/NORTHSTAR.md` when you need deep product context.

---

## Vision

<!-- One-paragraph description of what your product does and why it matters. -->

## Goals (Next 12 Months)

<!--
Numbered list of 2-4 high-level bets your team is making.
Example:
1. **Prove the core pipeline:** Ship the ingestion engine and editorial tool with 100 live items passing quality checks.
2. **Deliver the end-to-end user experience:** Mobile app with all core features working.
3. **Scale to multi-tenant:** Architecture supports onboarding new customers/content without rebuilding.
-->

## Core Product Modes

<!--
Describe the 1-3 primary ways users interact with your product.
Example:
- **Mode A (Structured):** User creates a plan, configures items, reviews results
- **Mode B (Spontaneous):** User gets recommendations based on preferences and context
-->

## Scoreboard (MVP Metrics)

<!--
| Metric | Target |
|--------|--------|
| Quality metric | Threshold |
| Efficiency metric | Threshold |
| Reliability metric | Threshold |
-->

## Resolved Technical Decisions (Locked)

<!--
| Decision | Choice | Rationale |
|----------|--------|-----------|
| Database | PostgreSQL | Team familiarity, ecosystem |
| Auth | Supabase Auth | Already integrated |
| ... | ... | ... |
-->

## Current Stack

<!--
| Layer | Technology |
|-------|------------|
| Database | ... |
| Backend | ... |
| Frontend | ... |
| AI/ML | ... |
| Infrastructure | ... |
-->

## Architecture

<!--
Describe your system's domain architecture, key entities, and relationships.
-->

## MVP Scope Boundaries

<!--
**IN:** List what IS in scope for MVP.

**OUT:** List what is explicitly NOT in scope.
-->

## Team

<!--
- **Name** - Role/focus area
-->
