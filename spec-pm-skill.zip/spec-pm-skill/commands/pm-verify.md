# Stage 5: Verification

You are a product management co-pilot running Stage 5 (Verification) of a spec-driven development workflow.

## Before You Start

Read these files for project context:
- `specs/NORTHSTAR.md` — project north star, architectural commitments, active build target
- `.claude/commands/product-context.md` — stable product knowledge, resolved decisions, current stack
- All spec artifacts in the current spec folder: `01-scope.md`, `02-spec.md`, `03-red-team.md`, `04-plan.md`

Read the actual code changes (use git diff against the base branch, or read the modified files listed in the plan).

## Your Task

Verify that the implementation matches the spec. This is the final quality gate before the feature is considered done.

## Output Format

Create the file `specs/YYYY-MM-DD-feature-name/05-verify.md` in the same folder.

```markdown
# Verification Report: [Feature Name]

**Date:** YYYY-MM-DD
**Status:** [Complete / Incomplete — N items failing]

---

## Acceptance Criteria — Pass/Fail

| AC | Description | Status | Evidence |
|----|------------|--------|----------|
| AC1 | [From spec] | PASS/FAIL | [Specific evidence: what you checked, what you found] |
| AC2 | ... | ... | ... |

---

## Tests Written and Status

| Test | Type | Status |
|------|------|--------|
| [Test from plan Part B] | Manual / Automated | PASS/FAIL |

---

## Best Practices Compliance

| # | Practice | Status | Evidence |
|---|----------|--------|----------|
| 1 | [From plan Part D] | PASS/FAIL | [What you checked] |

---

## Autonomous Decisions Made

Numbered list of any decisions the implementer made that weren't explicitly in the plan. For each:
- What was decided
- Why (reasoning)

If none, state "None — implementation followed the plan exactly."

---

## Scope Creep Check

Was anything built that wasn't in the spec? If yes, list it and flag for discussion.
If no: "No features were built beyond what was specified in the plan."

---

## Files Modified

- List all files that were created or modified

## Files NOT Modified (per plan)

- List files that the plan explicitly said not to touch, confirming they weren't touched
```

## Rules

1. **Read the actual code.** Don't trust summaries. Read the modified files and verify each acceptance criterion against the implementation.
2. **Evidence, not assertions.** For each AC, explain what you checked and what you found. "PASS — verified" is not evidence. "PASS — `validateSchema()` is called at line 342 before `processData()`, rejects files missing required fields with specific error messages" is evidence.
3. **Check for scope creep.** Compare the files modified against the plan's file list. Flag any unexpected files. Check for features or behaviors that weren't in the spec.
4. **Check autonomous decisions.** If the implementer made decisions not covered by the plan, list them. These aren't necessarily wrong — but they should be documented and reviewed.
5. **Binary verdicts.** Each AC is PASS or FAIL. No "partial pass" or "mostly works." If it doesn't fully pass, it fails.

## When Done

Present the verification report to the user. If all ACs pass, the feature is done. If any fail, list what needs to be fixed and the implementer should address the failures before re-running verification.
